# Files (Xiaomi-style file manager)

Kotlin + Jetpack Compose, minSdk 26 (Android 8+), Light / Dark / Auto theme.

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Build > Build APK(s), or Run on a device.
3. First launch: tap "Grant access" and allow "All files access".
